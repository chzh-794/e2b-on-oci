#!/bin/bash
# E2B on OCI - Complete POC Deployment Script
# This script deploys E2B across 3 OCI instances

set -e

# Configuration
SERVER_POOL_PUBLIC="192.29.244.233"
SERVER_POOL_PRIVATE="10.1.1.103"

API_POOL_PUBLIC="129.149.60.176"
API_POOL_PRIVATE="10.1.1.194"

CLIENT_POOL_PUBLIC="129.149.61.235"
CLIENT_POOL_PRIVATE="10.1.1.252"

# OCI Managed Services
POSTGRES_HOST="10.1.2.168"  # Using private IP instead of FQDN for reliability
POSTGRES_USER="postgres"
POSTGRES_PASSWORD="E2bPostgres123!"
POSTGRES_DB="postgres"  # Default PostgreSQL database
POSTGRES_PORT="5432"

REDIS_ENDPOINT="aaax7756raafjy7qgl2gzr3b5mlvu4z243b5cyv2rovw6g6bpr6iakq-p.redis.ap-osaka-1.oci.oraclecloud.com"
REDIS_PORT="6379"

SSH_USER="ubuntu"
SSH_KEY="$HOME/.ssh/id_rsa"
SSH_OPTS="-i ${SSH_KEY} -o StrictHostKeyChecking=no"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGES_DIR="${SCRIPT_DIR}/packages"

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║       E2B on OCI - POC Deployment                         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}Deployment Configuration:${NC}"
echo "  Server Pool:  ${SERVER_POOL_PUBLIC} (${SERVER_POOL_PRIVATE})"
echo "  API Pool:     ${API_POOL_PUBLIC} (${API_POOL_PRIVATE})"
echo "  Client Pool:  ${CLIENT_POOL_PUBLIC} (${CLIENT_POOL_PRIVATE})"
echo ""

# Phase 1: Install Dependencies
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 1: Installing Dependencies${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

# TEMPORARILY SKIP SERVER POOL - Not critical for POC
# echo -e "\n${YELLOW}[1/3] Installing dependencies on Server Pool...${NC}"
# ssh $SSH_OPTS ${SSH_USER}@${SERVER_POOL_PUBLIC} << 'ENDSSH'
# sudo apt update
# echo "✓ Package list updated"
# ENDSSH
echo -e "\n${YELLOW}[1/3] Skipping Server Pool (not critical for POC)...${NC}"

echo -e "\n${YELLOW}[2/3] Installing dependencies on API Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << 'ENDSSH'
set -e
sudo apt update
sudo DEBIAN_FRONTEND=noninteractive apt install -y wget postgresql-client
echo "✓ PostgreSQL client installed (using OCI managed database)"

# Install Go
if ! command -v go &> /dev/null; then
    cd /tmp
    wget -q https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    echo "✓ Go installed"
else
    echo "✓ Go already installed"
fi
ENDSSH

echo -e "\n${YELLOW}[3/3] Installing dependencies on Client Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${CLIENT_POOL_PUBLIC} << 'ENDSSH'
set -e
sudo apt update
sudo DEBIAN_FRONTEND=noninteractive apt install -y wget

# Install Go
if ! command -v go &> /dev/null; then
    cd /tmp
    wget -q https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    echo "✓ Go installed"
else
    echo "✓ Go already installed"
fi

# Load NBD kernel module
sudo modprobe nbd max_part=16 || true
echo "✓ NBD module loaded"

# Create template storage directory
sudo mkdir -p /var/e2b/templates
sudo chown -R $USER:$USER /var/e2b
echo "✓ Template storage directory created"
ENDSSH

echo -e "${GREEN}✓ Phase 1 Complete: All dependencies installed${NC}"

# Phase 2: Copy Source Code
echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 2: Copying Source Code${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}Copying packages to API Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} "mkdir -p ~/e2b"
scp $SSH_OPTS -r ${PACKAGES_DIR} ${SSH_USER}@${API_POOL_PUBLIC}:~/e2b/
echo "✓ Source code copied to API Pool"

echo -e "\n${YELLOW}Copying packages to Client Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${CLIENT_POOL_PUBLIC} "mkdir -p ~/e2b"
scp $SSH_OPTS -r ${PACKAGES_DIR} ${SSH_USER}@${CLIENT_POOL_PUBLIC}:~/e2b/
echo "✓ Source code copied to Client Pool"

echo -e "${GREEN}✓ Phase 2 Complete: Source code distributed${NC}"

# Phase 3: Verify OCI Managed Services Connectivity
echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 3: Verifying OCI Managed Services${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}Testing PostgreSQL connectivity from API Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << ENDSSH
set -e
export PGPASSWORD="${POSTGRES_PASSWORD}"
echo "Testing connection to ${POSTGRES_HOST}:${POSTGRES_PORT}..."
if timeout 10 psql -h ${POSTGRES_HOST} -p ${POSTGRES_PORT} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -c '\l' > /dev/null 2>&1; then
    echo "✓ PostgreSQL connection successful"
    echo "  Host: ${POSTGRES_HOST}"
    echo "  Database: ${POSTGRES_DB}"
else
    echo "✗ PostgreSQL connection failed or timed out"
    echo "  Checking if port is reachable..."
    nc -zv ${POSTGRES_HOST} ${POSTGRES_PORT} || echo "Port ${POSTGRES_PORT} is not reachable"
    exit 1
fi
ENDSSH

echo -e "\n${YELLOW}Testing Redis connectivity from API Pool...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << ENDSSH
set -e
sudo DEBIAN_FRONTEND=noninteractive apt install -y redis-tools > /dev/null 2>&1
echo "Testing Redis with TLS..."
if redis-cli -h ${REDIS_ENDPOINT} -p ${REDIS_PORT} --tls PING > /dev/null 2>&1; then
    echo "✓ Redis connection successful (TLS enabled)"
    echo "  Host: ${REDIS_ENDPOINT}"
else
    echo "✗ Redis connection failed"
    echo "  Endpoint: ${REDIS_ENDPOINT}:${REDIS_PORT}"
    exit 1
fi
ENDSSH

echo -e "${GREEN}✓ Phase 3 Complete: OCI managed services verified${NC}"

# Phase 4: Build Binaries on API Pool
echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 4: Building E2B Services on API Pool${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}Building API and Client Proxy...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << 'ENDSSH'
set -e
export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go

cd ~/e2b/packages/api
echo "Building e2b-api..."
go build -o ~/e2b/bin/e2b-api main.go
echo "✓ e2b-api built"

cd ~/e2b/packages/client-proxy
echo "Building client-proxy..."
go build -o ~/e2b/bin/client-proxy main.go
echo "✓ client-proxy built"

ls -lh ~/e2b/bin/
ENDSSH

echo -e "${GREEN}✓ Phase 4 Complete: API services built${NC}"

# Phase 5: Build Binaries on Client Pool
echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 5: Building E2B Services on Client Pool${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}Building Orchestrator and envd...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${CLIENT_POOL_PUBLIC} << 'ENDSSH'
set -e
export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go

mkdir -p ~/e2b/bin

cd ~/e2b/packages/orchestrator
echo "Building orchestrator..."
go build -o ~/e2b/bin/orchestrator main.go
ln -sf ~/e2b/bin/orchestrator ~/e2b/bin/template-manager
echo "✓ orchestrator built"

cd ~/e2b/packages/envd
echo "Building envd..."
go build -o ~/e2b/bin/envd main.go
echo "✓ envd built"

ls -lh ~/e2b/bin/
ENDSSH

echo -e "${GREEN}✓ Phase 5 Complete: Orchestrator services built${NC}"

# Phase 6: Create Configuration Files
echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Phase 6: Creating Configuration Files${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"

echo -e "\n${YELLOW}Creating API service configuration...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << ENDSSH
cat > ~/e2b/api.env << 'ENDENV'
# PostgreSQL Configuration (OCI Database)
POSTGRES_CONNECTION_STRING=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@${POSTGRES_HOST}:${POSTGRES_PORT}/${POSTGRES_DB}?sslmode=require

# Storage Configuration (Local for POC)
STORAGE_PROVIDER=local
LOCAL_TEMPLATE_STORAGE_BASE_PATH=/var/e2b/templates

# Redis Configuration (OCI Cache with TLS)
REDIS_URL=rediss://${REDIS_ENDPOINT}:${REDIS_PORT}

# Service Configuration
PORT=50001
LOG_LEVEL=debug

# Consul Configuration
CONSUL_URL=http://localhost:8500

# Cloud Provider
CLOUD_PROVIDER=oci
ENDENV
echo "✓ API configuration created"
ENDSSH

echo -e "\n${YELLOW}Creating Client Proxy configuration...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${API_POOL_PUBLIC} << ENDSSH
cat > ~/e2b/client-proxy.env << 'ENDENV'
# Service Configuration
PORT=3001
LOG_LEVEL=debug

# Consul Configuration
CONSUL_URL=http://localhost:8500

# Redis Configuration (OCI Cache with TLS)
REDIS_URL=rediss://${REDIS_ENDPOINT}:${REDIS_PORT}

# Cloud Provider
CLOUD_PROVIDER=oci
ENDENV
echo "✓ Client Proxy configuration created"
ENDSSH

echo -e "\n${YELLOW}Creating Orchestrator configuration...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${CLIENT_POOL_PUBLIC} << ENDSSH
cat > ~/e2b/orchestrator.env << 'ENDENV'
# Storage Configuration (Local for POC)
STORAGE_PROVIDER=local
LOCAL_TEMPLATE_STORAGE_BASE_PATH=/var/e2b/templates

# Firecracker Configuration
FIRECRACKER_BIN_PATH=/usr/local/bin/firecracker
KERNEL_PATH=/var/e2b/kernels/vmlinux-5.10
FIRECRACKER_VERSION=1.5.0

# NBD Configuration
NBD_POOL_SIZE=100

# Service Configuration
GRPC_PORT=5008
LOG_LEVEL=debug

# Consul Configuration
CONSUL_URL=http://localhost:8500

# Cloud Provider
CLOUD_PROVIDER=oci

# Allow Sandbox Internet
ALLOW_SANDBOX_INTERNET=true
ENDENV
echo "✓ Orchestrator configuration created"
ENDSSH

echo -e "\n${YELLOW}Creating Template Manager configuration...${NC}"
ssh $SSH_OPTS ${SSH_USER}@${CLIENT_POOL_PUBLIC} << ENDSSH
cat > ~/e2b/template-manager.env << 'ENDENV'
# Storage Configuration (Local for POC)
STORAGE_PROVIDER=local
LOCAL_TEMPLATE_STORAGE_BASE_PATH=/var/e2b/templates

# Firecracker Configuration
FIRECRACKER_BIN_PATH=/usr/local/bin/firecracker
KERNEL_PATH=/var/e2b/kernels/vmlinux-5.10
FIRECRACKER_VERSION=1.5.0

# Network
GRPC_PORT=5009
PROXY_PORT=15007

# Service Configuration
LOG_LEVEL=debug
CLOUD_PROVIDER=oci

ENDENV
echo "✓ Template Manager configuration created"
ENDSSH

echo -e "${GREEN}✓ Phase 6 Complete: Configuration files created${NC}"

# Summary
echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║       Deployment Complete!                                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}✓ All services deployed and configured${NC}"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo "1. Configure Nomad/Consul cluster (servers and clients)"
echo "2. Download Firecracker binaries to Client Pool"
echo "3. Start the services"
echo ""
echo -e "${YELLOW}To start services manually:${NC}"
echo ""
echo -e "  ${BLUE}On API Pool (${API_POOL_PUBLIC}):${NC}"
echo "    source ~/e2b/api.env && ~/e2b/bin/e2b-api"
echo "    source ~/e2b/client-proxy.env && ~/e2b/bin/client-proxy"
echo ""
echo -e "  ${BLUE}On Client Pool (${CLIENT_POOL_PUBLIC}):${NC}"
echo "    source ~/e2b/orchestrator.env && ~/e2b/bin/orchestrator"
echo "    source ~/e2b/template-manager.env && ~/e2b/bin/template-manager"
echo ""
echo -e "${YELLOW}OCI Managed Services:${NC}"
echo "  PostgreSQL: ${POSTGRES_HOST}:${POSTGRES_PORT}"
echo "    Database: ${POSTGRES_DB}"
echo "    User: ${POSTGRES_USER}"
echo "    Password: ${POSTGRES_PASSWORD}"
echo ""
echo "  Redis: ${REDIS_ENDPOINT}:${REDIS_PORT}"
echo ""

